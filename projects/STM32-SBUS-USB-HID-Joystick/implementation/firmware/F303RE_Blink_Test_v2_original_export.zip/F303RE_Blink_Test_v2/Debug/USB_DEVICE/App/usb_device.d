USB_DEVICE/App/usb_device.o: ../USB_DEVICE/App/usb_device.c \
 ../USB_DEVICE/App/usb_device.h \
 ../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f3xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f303xe.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F3xx/Include/system_stm32f3xx.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal.h \
 ../Core/Inc/stm32f3xx_hal_conf.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_def.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_exti.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_cortex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pcd.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_ll_usb.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pcd_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart_ex.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h \
 ../USB_DEVICE/Target/usbd_conf.h ../Core/Inc/main.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ctlreq.h \
 ../USB_DEVICE/App/usbd_desc.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Class/CustomHID/Inc/usbd_customhid.h \
 ../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h \
 ../USB_DEVICE/App/usbd_custom_hid_if.h
../USB_DEVICE/App/usb_device.h:
../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f3xx.h:
../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f303xe.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F3xx/Include/system_stm32f3xx.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal.h:
../Core/Inc/stm32f3xx_hal_conf.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_def.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_exti.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_cortex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pcd.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_ll_usb.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pcd_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart_ex.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h:
../USB_DEVICE/Target/usbd_conf.h:
../Core/Inc/main.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ctlreq.h:
../USB_DEVICE/App/usbd_desc.h:
../Middlewares/ST/STM32_USB_Device_Library/Class/CustomHID/Inc/usbd_customhid.h:
../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h:
../USB_DEVICE/App/usbd_custom_hid_if.h:
